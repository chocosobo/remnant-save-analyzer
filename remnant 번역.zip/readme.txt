번역 현황 및 최신 번역, 적용방법 링크
http://wiki.chocosobo.com/remnant/번역

이 파일은 2020/02/07 갱신된 파일입니다

번역파일
pakchunk0-WindowsNoEditor_P

폰트파일
pakchunk1-WindowsNoEditor_P